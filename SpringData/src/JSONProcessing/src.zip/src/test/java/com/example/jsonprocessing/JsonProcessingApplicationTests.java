package com.example.jsonprocessing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsonProcessingApplicationTests {

    @Test
    void contextLoads() {
    }

}
